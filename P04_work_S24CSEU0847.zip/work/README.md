# P04 — From Notebook to Package

## Run
From this directory, with the course environment activated:

```bash
python train.py ../data/delivery_times.csv
python predict.py
```

The training script saves `model.joblib` in this directory. The prediction
script loads that saved model and prints a `PREDICTION:` line.

## Module responsibilities
- `delivery/__init__.py`: exposes the package's public API and version.
- `delivery/data.py`: loads the delivery CSV and creates the train/test split.
- `delivery/features.py`: describes orders and calculates per-order features.
- `delivery/model.py`: trains, evaluates, saves, and loads the model.
- `delivery/validate.py`: validates delivery-order input fields.
- `train.py`: runs the training pipeline from the command line.
- `predict.py`: loads the saved model and predicts one order.

## AI assistance disclosure
AI assistance (ChatGPT) was used to help debug and complete the practical
implementation. The submitted code was executed and checked; the student is
responsible for understanding, explaining, and modifying it.
