"Is this order usable?"


def is_valid_order(order):
    "True if the order passes every rule."
    required = ("distance_km", "prep_time_min", "traffic_level", "rain")
    if not isinstance(order, dict) or any(key not in order for key in required):
        return False
    try:
        if order["distance_km"] <= 0:
            return False
        if order["prep_time_min"] < 0:
            return False
        if order["traffic_level"] not in (1, 2, 3):
            return False
        if order["rain"] not in (0, 1):
            return False
    except (TypeError, ValueError):
        return False
    return True
